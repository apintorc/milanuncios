package com.example.microAnuncios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroAnunciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroAnunciosApplication.class, args);
	}

}
